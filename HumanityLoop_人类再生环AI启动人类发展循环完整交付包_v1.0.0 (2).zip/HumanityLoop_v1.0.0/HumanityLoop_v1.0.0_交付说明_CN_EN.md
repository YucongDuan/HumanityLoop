# HumanityLoop v1.0.0 交付说明 / Delivery Guide

## 中文

HumanityLoop 将“AI发展启动人类发展的新循环”落实为可运行系统：

```text
人类需要
→ AI有界介入
→ 人类行动
→ 现实结果
→ 可迁移能力返还
→ 经同意的公共品或正当私域知识返还
→ 反馈、纠错与修复
→ 人类接棒与继任
→ 下一轮人类发展
```

系统通过九个不可补偿再生门判断循环是否闭合：能力返还、现实反馈、知识返还、多样性、资源承载力、退出接棒、来源同意、伤害修复和继任种子。它不生成“人的价值总分”或“再生总分”。

百度视频页面在构建环境中未能可靠抽取，因此系统只采用用户明确提出的生态循环启发，不对视频中的具体细节作未经核验的引用。

### 快速运行

```bash
python humanityloop.py new data/samples/seed_input.json --out outputs/my_cycle.json
python humanityloop.py audit data/samples/regenerative_cycle.json
python humanityloop.py handoff data/samples/extractive_cycle.json --out outputs/handoff.json
python humanityloop.py commons-export data/samples/regenerative_cycle.json --out outputs/public.json
python humanityloop.py compare data/samples/regenerative_cycle.json data/samples/extractive_cycle.json --out outputs/comparison.json
```

### 原地接入现有旗舰

```bash
python integration/install_into_existing_flagship.py /path/to/existing-flagship
```

安装器写入 `modules/humanityloop/`，保存迁移前Git HEAD并生成安装收据；不自动Push，也不创建新仓库。

## English

HumanityLoop turns the idea of AI as the starter of a new human-development cycle into a runnable system. Nine non-compensable gates track capability return, real-world feedback, knowledge return, diversity, carrying capacity, exit/handoff, provenance/consent, harm/repair and succession.

The system produces neither an aggregate regeneration score nor a human-value score. Private experience cannot be converted into public “compost” without explicit, revocable consent.

The supplied Baidu video page could not be reliably extracted in the build environment. HumanityLoop therefore uses only the user's explicit ecological-cycle framing and attributes no unverified detailed claim to the video.

Prefer integration into an existing flagship before creating another repository.
